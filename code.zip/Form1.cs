﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlCommand cmd = new SqlCommand("select * from user_master where username_emailid=@username_emailid and password_=@password_", DbConnection.conn))
            {
                DataTable dt = new DataTable();
                //username_emailid,password_
                cmd.Parameters.AddWithValue("@username_emailid", textBox1.Text);
                cmd.Parameters.AddWithValue("@password_", textBox2.Text);
                using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                {
                    adp.Fill(dt);
                }
                if (dt.Rows.Count > 0)
                {
                    //afterloginhome
                    DbConnection.id = dt.Rows[0].ItemArray[0].ToString();
                    home h = new home();
                    this.Hide();
                    h.Show();
                }
                else
                {
                    MessageBox.Show("Invalid Credentails!!");
                    textBox1.Focus();
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            registration rr = new registration();
            rr.Show();
            this.Hide();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = "";
        }
    }
}
