﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{

    class DbConnection
    {
        public static readonly SqlConnection conn = new SqlConnection("DATA SOURCE=.;Initial Catalog=kanchan_db;Integrated Security=TRUE");
        public static string id = "";
        public static Bitmap bmp;
    }

}
