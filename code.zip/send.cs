﻿using QRCodeSample;
using Steganography;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class send : Form
    {
        public send()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"C:\",
                Title = "Browse VIDEO Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = ".mp4",
                Filter = "Media Files|*.mpg;*.avi;*.wma;*.mov;*.wav;*.mp2;*.mp3|All Files|*.*",

            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                label3.Text = openFileDialog1.FileName;
            }
        }
        private void button21_Click(object sender, EventArgs e)
        {
            byte[] bytes = System.IO.File.ReadAllBytes(label3.Text);
            TypeConverter tc = TypeDescriptor.GetConverter(typeof(Bitmap));
            Bitmap secretGreyScale = (Bitmap)tc.ConvertFrom(bytes);
            BBSGenerator2 bs = new BBSGenerator2(secretGreyScale);
            int vdcontent = Convert.ToInt32(bs);
            int embedded = Convert.ToInt32(SteganographyHelper.embedText(textBox2.Text, vdcontent));
            byte[] bytes1 = BitConverter.GetBytes(embedded);
            File.WriteAllBytes("",bytes1);
            //  send_maiL_();
            var sourceFile = label3.Text;
            var saveFileDialog = new SaveFileDialog();
            //You can offer a default name
            saveFileDialog.FileName = "1.mp4";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                System.IO.File.Copy(sourceFile, saveFileDialog.FileName);
            }

        }
        private void send_maiL_()
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("singh.mona999@gmail.com");
            mail.To.Add(textBox1.Text);
            mail.Subject = "INFORMATION";
            mail.Body = "Your Secret key is : " + textBox3.Text + "";
            SmtpServer.Port = 587;
            SmtpServer.UseDefaultCredentials = false;
            SmtpServer.EnableSsl = true;
            SmtpServer.Credentials = new System.Net.NetworkCredential("singh.mona999@gmail.com", "Beawar@123");
            SmtpServer.Send(mail);
            MessageBox.Show("mail Send");
            ///////////-------------------------------------------------
            //MailMessage msg = new MailMessage();

            //msg.From = new MailAddress("singh.mona999@gmail.com");
            //msg.To.Add(textBox1.Text);
            //msg.Subject = "INFORMATION";
            //msg.Body = "Your Secret key is : " + textBox3.Text + "";
            ////msg.Priority = MailPriority.High;

            //using (SmtpClient client = new SmtpClient())
            //{
            //    client.EnableSsl = true;
            //    client.UseDefaultCredentials = false;
            //    client.Credentials = new NetworkCredential("singh.mona999@gmail.com", "Beawar@123"); 
            //    client.Host = "smtp.gmail.com";
            //    client.Port = 588;
            //    client.DeliveryMethod = SmtpDeliveryMethod.Network;
            //    client.Send(msg); 
            //    MessageBox.Show("mail Send");
            //}

        }

        public class RandomGenerator
        {
            public int RandomNumber(int min, int max)
            {
                Random random = new Random();
                return random.Next(min, max);
            }
        }






























































































































        #region comments

        private void button3_Click(object sender, EventArgs e)
        {
            check_();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                using (SqlCommand cmd = new SqlCommand("insert into storage_master(receiv_eid, video_url, vid_data, secret_text,systemotp_) values(@receiv_eid, @video_url, @vid_data, @secret_text,@systemotp_)", DbConnection.conn))
                {
                    byte[] bytes = System.IO.File.ReadAllBytes(label3.Text);
                    cmd.Parameters.AddWithValue("@receiv_eid", textBox1.Text);
                    cmd.Parameters.AddWithValue("@video_url", label3.Text);
                    cmd.Parameters.AddWithValue("@vid_data", bytes);
                    cmd.Parameters.AddWithValue("@secret_text", textBox2.Text);
                    cmd.Parameters.AddWithValue("@systemotp_", textBox3.Text);
                    DbConnection.conn.Open();
                    cmd.ExecuteNonQuery();
                    DbConnection.conn.Close();
                }
               // send_mail_();
                var sourceFile = label3.Text;
                var saveFileDialog = new SaveFileDialog();
                //You can offer a default name
                saveFileDialog.FileName = "1.mp4";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    System.IO.File.Copy(sourceFile, saveFileDialog.FileName);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void send_mail_()
        {
            MailMessage mail = new MailMessage();
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("singh.mona999@gmail.com");
            mail.To.Add(textBox1.Text);
            mail.Subject = "INFORMATION";
            mail.Body = "Your Secret key is : " + textBox3.Text + "";
            SmtpServer.Port = 587;
            SmtpServer.Credentials = new System.Net.NetworkCredential("singh.mona999@gmail.com", "Beawar@123");
            SmtpServer.EnableSsl = true;
            SmtpServer.UseDefaultCredentials = true;
            SmtpServer.Send(mail);
            MessageBox.Show("mail Send");
        }
        private void check_()
        {
            RandomGenerator generator = new RandomGenerator();
            int rand = generator.RandomNumber(1000, 9999);
            DataTable dt = new DataTable();
            using (SqlCommand cmd = new SqlCommand("select * from storage_master where receiv_eid=@receiv_eid and systemotp_=@systemotp_", DbConnection.conn))
            {
                cmd.Parameters.AddWithValue("@receiv_eid", textBox1.Text);
                cmd.Parameters.AddWithValue("@systemotp_", rand);
                using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                {
                    adp.Fill(dt);
                }
            }
            if (dt.Rows.Count == 0)
            {
                textBox3.Text = rand.ToString();
            }
            else
            {
                check_();
            }
        }

        #endregion

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
