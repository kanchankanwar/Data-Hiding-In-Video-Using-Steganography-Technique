﻿using QRCodeSample;
using Steganography;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class receive : Form
    {
        public receive()
        {
            InitializeComponent();
        }

        private void receive_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlCommand cmd = new SqlCommand("select username_emailid from user_master where id=@id", DbConnection.conn))
            {
                cmd.Parameters.AddWithValue("@id", DbConnection.id);
                using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                {
                    adp.Fill(dt);
                }
            }
            if (dt.Rows.Count > 0)
            {
                textBox1.Text = dt.Rows[0].ItemArray[0].ToString();
            }
            else
            {
                textBox1.Text = "";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"C:\",
                Title = "Browse VIDEO Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = ".mp4",
                Filter = "Media Files|*.mpg;*.avi;*.wma;*.mov;*.wav;*.mp2;*.mp3|All Files|*.*",

            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                label3.Text = openFileDialog1.FileName;
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            byte[] bytes = System.IO.File.ReadAllBytes(label3.Text);
            TypeConverter tc = TypeDescriptor.GetConverter(typeof(Bitmap));
            Bitmap secretGreyScale = (Bitmap)tc.ConvertFrom(bytes);
            BBSGenerator2 bs = new BBSGenerator2(secretGreyScale);
            int vdcontent = Convert.ToInt32(bs);
            int embedded = Convert.ToInt32(SteganographyHelper.extractText(vdcontent));
            textBox3.Text = embedded.ToString();
        }









































































        #region Comments
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox2.Text != "")
                {
                    byte[] bytes = System.IO.File.ReadAllBytes(label3.Text);
                    DataTable dt = new DataTable();
                    using (SqlCommand cmd = new SqlCommand("select secret_text from storage_master where vid_data=@vid_data and receiv_eid=@receiv_eid and systemotp_=@systemotp_", DbConnection.conn))
                    {
                        //  vid_data,receiv_eid,systemotp_
                        cmd.Parameters.AddWithValue("@vid_data", bytes);
                        cmd.Parameters.AddWithValue("@receiv_eid", textBox1.Text);
                        cmd.Parameters.AddWithValue("@systemotp_", textBox2.Text);
                        using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                        {
                            adp.Fill(dt);
                        }
                    }
                    if (dt.Rows.Count > 0)
                    {
                        textBox3.Text = dt.Rows[0].ItemArray[0].ToString();
                    }
                    else
                    {
                        textBox3.Text = "";
                        MessageBox.Show("No Secret Text Found!");
                    }
                }
                else
                {
                    MessageBox.Show("ENTER OTP");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        #endregion
    }
}
