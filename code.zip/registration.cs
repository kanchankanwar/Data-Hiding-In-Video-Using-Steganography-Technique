﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class registration : Form
    {
        public registration()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlCommand cmd = new SqlCommand("select * from user_master where username_emailid=@username_emailid", DbConnection.conn))
            {
                //username_emailid
                cmd.Parameters.AddWithValue("@username_emailid", textBox2.Text);
                using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                {
                    adp.Fill(dt);
                }
            }
            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("USER EMAIL ID ALREADY EXITS!!");
                textBox2.Focus();
            }
            else
            {
                using (SqlCommand cmd1 = new SqlCommand("insert into user_master(username_emailid,phone_no,password_,name_) values(@username_emailid,@phone_no,@password_,@name_)", DbConnection.conn))
                {
                    //username_emailid,phone_no,password_,name_
                    cmd1.Parameters.AddWithValue("@username_emailid", textBox2.Text);
                    cmd1.Parameters.AddWithValue("@phone_no", textBox3.Text);
                    cmd1.Parameters.AddWithValue("@password_", textBox4.Text);
                    cmd1.Parameters.AddWithValue("@name_", textBox1.Text);
                    DbConnection.conn.Open();
                    cmd1.ExecuteNonQuery();
                    DbConnection.conn.Close();
                    this.Close();
                    Form1 f1 = new Form1();
                    f1.Show();
                }
            }
        }
    }
}
