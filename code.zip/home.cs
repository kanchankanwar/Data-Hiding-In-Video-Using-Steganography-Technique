﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void home_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlCommand cmd = new SqlCommand("select name_ from user_master where id=@id", DbConnection.conn))
            {
                cmd.Parameters.AddWithValue("@id", DbConnection.id);
                using(SqlDataAdapter adp=new SqlDataAdapter(cmd))
                {
                    adp.Fill(dt);
                }
            }
            label1.Text = "Welcome "+dt.Rows[0].ItemArray[0].ToString();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            Form1 g = new Form1();
            g.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            send ss = new send();
            ss.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            receive rr = new receive();
            rr.Show();
        }
    }
}
